﻿using System;

interface IVehicle
{
	void Input();
	void Output();
}
