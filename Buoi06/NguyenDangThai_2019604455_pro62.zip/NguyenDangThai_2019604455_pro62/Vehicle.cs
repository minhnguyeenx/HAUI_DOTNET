﻿using System;

public class Vehicles: IVehicle
{
	string id;
	string maker;
	string model;
	int year;
	double price;

	public Vehicles()
	{
		this.id = "VD00";
		this.maker = "Vinfast";
		this.model = "Lux 2.0";
		this.year = 2020;
		this.price = 2000;
	}

	public Vehicles(string id, string maker, string model, int year, double price)
    {
		this.id = id;
		this.maker = maker;
		this.model = model;
		this.year = year;
		this.price = price;
    }
	public virtual void Input()
    {
		Console.WriteLine("ID: ");
		this.id = Console.ReadLine();
		Console.WriteLine("Maker: ");
		this.id = Console.ReadLine();
		Console.WriteLine("Model: ");
		this.id = Console.ReadLine();
		Console.WriteLine("Year: ");
		this.year = Int32.Parse(Console.ReadLine());
		Console.WriteLine("Price: ");
		this.price = Double.Parse(Console.ReadLine());
	}

	public virtual void Output()
    {
		Console.WriteLine("ID: " + this.id);
		Console.WriteLine("Maker: " + this.maker);
		Console.WriteLine("Model: " + this.model);
		Console.WriteLine("Year: " + this.year);
		Console.WriteLine("Price: " + this.price);
	}

    public override string ToString()
    {
		return string.Format("{0}\t{1}\t{2}\t{3}", this.id, this.maker, this.model, this.price);
    }

    public override bool Equals(object obj)
    {
		Vehicles item = obj as Vehicles;

        if(item.id == this.id)
        {
			return true;
        } else
        {
			return false;
        }
    }
}
