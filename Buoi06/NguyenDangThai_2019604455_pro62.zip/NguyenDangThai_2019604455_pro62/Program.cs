﻿using System;

namespace NguyenDangThai_2019604455_pro62
{
    class Program
    {
        static void Main(string[] args)
        {
            Vehicles vehicle = new Vehicles("VD02", "Toyota", "Toyota 1.0", 2022, 50000);
            Vehicles vehicleEx = new Vehicles();
            vehicle.Equals(vehicleEx);
            Console.WriteLine(vehicle.Equals(vehicleEx));

        }
    }
}
