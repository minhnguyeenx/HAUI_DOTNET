﻿using System;

public class Truck : Vehicles
{
    int truckload;

    public Truck()
    {

    }
}
