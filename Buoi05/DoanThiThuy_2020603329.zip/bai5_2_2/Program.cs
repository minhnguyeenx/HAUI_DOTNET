﻿using System;
using System.Text;
using bai5_2_2;

namespace BaiTap2_5_2
{
    class Program
    {
        static void Main(string[] args)
        {
            

            Console.Write("Nhập a: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nhập b: ");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nhập c: ");
            int c = Convert.ToInt32(Console.ReadLine());

            GiaiPhuongTrinhBacHai pt = new GiaiPhuongTrinhBacHai(a,b,c);
        }
    }
}

